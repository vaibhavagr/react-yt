import React from 'react'

import amazon from './assets/amazon.png'
import { Bookmark } from 'lucide-react';
const Card = () => {
  return (
     <div className="card">
        <div className="top">
          <img src={amazon} alt="profile" / >
          <button>Save <Bookmark /></button>
        </div>
        <div className="center">
          <h3>Amazon <span> 5 days ago</span></h3>
          <h3>Senior UI/UX Designer</h3>
          <div>
            <h4>Part Time</h4>
            <h4>Senior Level</h4>
          </div>
        </div>
        <div className="bottom">
          <div>
            <h3>$120/hr</h3>
            <p>Mumbai ,India</p>
          </div>
          <button>Apply Now</button>
        </div>
      </div>
  )
}

export default Card
